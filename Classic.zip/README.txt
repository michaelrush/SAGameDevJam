HELM'S DEEP

CONTROLS
Arrow Keys to move, Z to shoot and X to bomb.

CREDITS
Created by Living One Post at a Time for the SAGameJam on 3/23/12
Developed on the XNA 4.0 Framework